<?php
    /*********************************************************************************
     * 
     ********************************************************************************/

    /**
     * Helper class for Customext customizations.
     */
    class CustomextInstallUtil
    {
        public static function resolveCustomMetadataAndLoad()
        { 
            $shouldSaveZurmoModuleMetadata = false;
            $metadata                      = ZurmoModule::getMetadata();
            //Add Material to Menu if it doesn't exist
            if(!in_array('costbook', $metadata['global']['tabMenuItemsModuleOrdering']))
            {
                $metadata['global']['tabMenuItemsModuleOrdering'][] = 'costbook';                
                $shouldSaveZurmoModuleMetadata = true;
            }            
            if(!in_array('departmentReferences', $metadata['global']['tabMenuItemsModuleOrdering']))
            {
                $metadata['global']['tabMenuItemsModuleOrdering'][] = 'departmentReferences';                
                $shouldSaveZurmoModuleMetadata = true;
            } 
            
            if($shouldSaveZurmoModuleMetadata)
            {
                ZurmoModule::setMetadata($metadata);
                GeneralCache::forgetAll();
            }
            
            Yii::import('application.extensions.zurmoinc.framework.data.*');

            
            
        }
    }
?>
